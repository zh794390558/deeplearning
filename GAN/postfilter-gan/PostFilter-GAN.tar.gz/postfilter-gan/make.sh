#!/bin/bash

set -x

if [[ $# != 1 ]]; then
    echo "usage: ./make.sh [test|lsf|mcep]"
    exit 1
elif [[ $# == 1 ]]; then
    if [[ $1 == 'test' ]]; then
    # test with 30 examples
        python make_tfrecords.py \
            --cfg cfg/postfilter.toml\
            --examples 30\
            --save_path data \
            --meta_save mean-std-meta.hdf5 \
            --frames 200 \
            --overlap 0.5 \
            --feature_size 41 \
            --feature_type mcep \
            --test_size 0.01 \
            --val_size 0.1 \
            --force-gen \
            --normal
    elif [[ $1 == 'lsf' ]]; then
        python make_tfrecords.py \
            --cfg cfg/postfilter.toml \
            --save_path /gfs/atlastts/StandFemale_22K/tfrecords \
            --meta_save mean-std-meta.hdf5 \
            --frames 200 \
            --overlap 0.5 \
            --feature_size 41 \
            --feature_type lsf \
            --test_size 0.01 \
            --val_size 0.1 \
            --force-gen \
            --normal
    elif [[ $1 == 'mcep' ]]; then
        python make_tfrecords.py \
            --cfg cfg/postfilter.toml \
            --save_path /gfs/atlastts/StandFemale_22K/tfrecords/mcep \
            --feature_type mcep \
            --frames 200 \
            --feature_size 41 \
            --overlap 0.5 \
            --test_size 0.01 \
            --val_size 0.1 \
            --force-gen
            #--meta_save mean-std-meta.hdf5 \
            #--normal \
    elif [[ $1 == 'mcep_normal' ]]; then
        python make_tfrecords.py \
            --cfg cfg/postfilter.toml \
            --save_path /gfs/atlastts/StandFemale_22K/tfrecords/mcep_normal \
            --meta_save mean-std-meta.hdf5 \
            --feature_type mcep \
            --frames 200 \
            --feature_size 41 \
            --overlap 0.5 \
            --test_size 0.01 \
            --val_size 0.1 \
            --normal \
            --force-gen
    elif [[ $1 == 'mcep_cut' ]]; then
        python make_tfrecords.py \
            --cfg cfg/postfilter.toml \
            --save_path /gfs/atlastts/StandFemale_22K/tfrecords/mcep_cut_normal \
            --meta_save mean-std-meta.hdf5 \
            --feature_type mcep_cut \
            --frames 200 \
            --feature_size 41 \
            --overlap 0.5 \
            --test_size 0.01 \
            --val_size 0.1 \
            --force-gen \
            --normal
    elif [[ $1 == 'mcep_cut_raw' ]]; then
        python make_tfrecords.py \
            --cfg cfg/postfilter.toml \
            --save_path /lustre/atlas/zhanghui/StandFemale_22K/tfrecords/mcep_cut_raw \
            --feature_type mcep_cut \
            --frames 200 \
            --feature_size 41 \
            --overlap 0.5 \
            --test_size 0.01 \
            --val_size 0.1 \
            --force-gen
            #--meta_save mean-std-meta.hdf5 \
            #--normal \
            #--save_path /gfs/atlastts/StandFemale_22K/tfrecords/mcep_cut_raw \

    fi

fi



