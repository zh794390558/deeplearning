#!/bin/bash

set -x

if [[ $# > 1 ]]; then
    echo "usage: ./make.sh [test]"
elif [[ $# == 1 ]]; then
    if [[ $1 == 'test' ]]; then
        python gen_wav.py \
            --feature_dir data/mcep \
            --feature_type lsf \
            --f0_dir /gfs/atlastts/StandFemale_22K/nature/postf0 \
            --wav_dir data/wav \
            --tool_dir tools

    elif [[ $1 == 'lsf' ]]; then
        python gen_wav.py \
            --feature_dir /gfs/atlastts/StandFemale_22K/lsf \
            --feature_type lsf \
            --f0_dir /gfs/atlastts/StandFemale_22K/nature/postf0 \
            --wav_dir /gfs/atlastts/StandFemale_22K/wav \
            --tool_dir tools
    elif [[ $1 == 'mcep' ]]; then
        python gen_wav.py \
            --examples 30 \
            --feature_dir /gfs/atlastts/StandFemale_22K/inference/mcep \
            --feature_type mcep \
            --f0_dir /gfs/atlastts/StandFemale_22K/MCEP/gen_par/f0 \
            --wav_dir /gfs/atlastts/StandFemale_22K/wav/mcep \
            --tool_dir tools
            #--f0_dir /gfs/atlastts/StandFemale_22K/MCEP/nature_par/postf0 \
    elif [[ $1 == 'mcep_cut' ]]; then
        python gen_wav.py \
            --examples 30 \
            --feature_type mcep \
            --tool_dir tools \
            --f0_dir /lustre/atlas/zhanghui/StandFemale_22K/MCEP/gen_par/f0_cut \
            --feature_dir /lustre/atlas/zhanghui/StandFemale_22K/inference/mcep_cut_normal/2gpu \
            --wav_dir /lustre/atlas/zhanghui/StandFemale_22K/wav/mcep_cut_normal/2gpu
    elif [[ $1 == 'mcep_cut_raw' ]]; then
        python gen_wav.py \
            --examples 30 \
            --feature_dir /lustre/atlas/zhanghui/StandFemale_22K/inference/mcep_cut_raw/ \
            --f0_dir /lustre/atlas/zhanghui/StandFemale_22K/MCEP/gen_par/f0_cut \
            --feature_type mcep \
            --wav_dir /lustre/atlas/zhanghui/StandFemale_22K/wav/mcep_cut_raw \
            --tool_dir tools

    fi

fi



