#!/bin/bash

set -x

if [[ $# > 1 ]]; then
    echo "usage: ./draw.sh [test]"
    exit 1
elif [[ $# == 1 ]]; then
    if [[ $1 == 'test' ]]; then
        python draw_mcep.py \
            --save data/png\
            --nat /lustre/atlas/zhanghui/StandFemale_22K/MCEP/nature_par/scep \
            --syn /lustre/atlas/zhanghui/StandFemale_22K/MCEP/gen_par/mcep \
            --enforce data/lsf

    elif [[ $1 == 'mcep' ]]; then
        python draw_mcep.py \
            --save /gfs/atlastts/StandFemale_22K/png/mcep \
            --nat /lustre/atlas/zhanghui/StandFemale_22K/MCEP/nature_par/scep \
            --syn /lustre/atlas/zhanghui/StandFemale_22K/MCEP/gen_par/mcep \
            --enforce /gfs/atlastts/StandFemale_22K/inference/mcep

    elif [[ $1 == 'mcep_cut_raw' ]]; then
          python draw_mcep.py \
            --save /gfs/atlastts/StandFemale_22K/png/mcep_cut_raw \
            --nat /lustre/atlas/zhanghui/StandFemale_22K/MCEP/nature_par/scep_cut \
            --syn /lustre/atlas/zhanghui/StandFemale_22K/MCEP/gen_par/mcep_cut \
            --enforce /lustre/atlas/zhanghui/StandFemale_22K/inference/mcep_cut_raw/ 
    fi

fi

