#!/bin/bash

pip install --user -r requirements.txt
