#!/bin/bash

set -x

if [[ $# > 1 ]]; then
    echo "usage: ./evaluation.sh [test]"
    exit 1
elif [[ $# == 1 ]]; then
    if [[ $1 == 'test' ]]; then

        # The src must split batch_size with gpu numbers,
        # so we use GPU0 to evalution, then the batch_size can be one without any error,
        # or Must satisfy `batch_size % n_gpu == 0`
        CUDA_VISIBLE_DEVICES=0 python model/main.py \
            --batch_size 1\
            --epoch 1 \
            --seed 10 \
            --bitdepth 32 \
            --noshuffle \
            --network model.py \
            --networkDirectory . \
            --weights log/train/gan_2.ckpt  \
            --inference_db data/test\
            --inference_save data/lsf \
            --noserving_export
            #--log_device_placement \
            #--log_runtime_stats_per_step 2 \

    elif [[ $1 == 'lsf' ]]; then
        CUDA_VISIBLE_DEVICES=-1 python model/main.py  \
            --batch_size 1 \
            --epoch 1 \
            --seed 10 \
            --bitdepth 32 \
            --noshuffle \
            --network model.py \
            --networkDirectory . \
            --weights /gfs/atlastts/StandFemale_22K/log/train/gan_18977.ckpt \
            --inference_save /gfs/atlastts/StandFemale_22K/inference/lsf \
            --inference_db /gfs/atlastts/StandFemale_22K/tfrecords/test \
            --inference_suffix mcep \
            --noserving_export
            #--log_device_placement \
            #--log_runtime_stats_per_step 2 \

    elif [[ $1 == 'mcep' ]]; then
        CUDA_VISIBLE_DEVICES=1 python model/main.py  \
            --batch_size 1 \
            --epoch 1 \
            --seed 10 \
            --bitdepth 32 \
            --noshuffle \
            --inference_suffix mcep \
            --network model.py \
            --networkDirectory . \
            --weights /gfs/atlastts/StandFemale_22K/log/mcep/train/mcep_74.ckpt \
            --inference_save /gfs/atlastts/StandFemale_22K/inference/mcep \
            --inference_db /gfs/atlastts/StandFemale_22K/tfrecords/mcep/test \
            --noserving_export
            #--log_device_placement \
            #--log_runtime_stats_per_step 2 \
    elif [[ $1 == 'mcep_normal' ]]; then
        CUDA_VISIBLE_DEVICES=1 python model/main.py  \
            --batch_size 1 \
            --epoch 1 \
            --seed 10 \
            --bitdepth 32 \
            --noshuffle \
            --inference_suffix mcep \
            --network model.py \
            --networkDirectory . \
            --weights /gfs/atlastts/StandFemale_22K/log/mcep/train/mcep_74.ckpt \
            --inference_save /gfs/atlastts/StandFemale_22K/inference/mcep_normal \
            --inference_db /gfs/atlastts/StandFemale_22K/tfrecords/mcep_normal/test \
            --noserving_export
            #--log_device_placement \
            #--log_runtime_stats_per_step 2 \
    elif [[ $1 == 'mcep_cut' ]]; then
        CUDA_VISIBLE_DEVICES=-1 python model/main.py  \
            --batch_size 1 \
            --epoch 1 \
            --seed 10 \
            --bitdepth 32 \
            --noshuffle \
            --inference_suffix mcep \
            --network model.py \
            --networkDirectory . \
	        --examples 30 \
            --inference_db /gfs/atlastts/StandFemale_22K/tfrecords/mcep_cut_normal/mos \
            --metapath /gfs/atlastts/StandFemale_22K/tfrecords/mcep_cut_normal/meta/mcep_cut/mean-std-meta.hdf5 \
            --weights /lustre/atlas/zhanghui/StandFemale_22K/log/mcep_cut/train/2gpu/lsgan_l1_1e-6_565.ckpt\
            --inference_save /lustre/atlas/zhanghui/StandFemale_22K/inference/mcep_cut_normal/2gpu \
            --noserving_export
    elif [[ $1 == 'mcep_cut_raw' ]]; then
        CUDA_VISIBLE_DEVICES=-1 python model/main.py  \
            --batch_size 1 \
            --epoch 1 \
            --seed 10 \
            --bitdepth 32 \
            --noshuffle \
            --inference_suffix mcep \
            --network model.py \
            --networkDirectory . \
	        --examples 30 \
            --weights /lustre/atlas/zhanghui/StandFemale_22K/log/mcep_cut_raw/train/100f/mcep_cut_raw_5.ckpt \
            --inference_save /lustre/atlas/zhanghui/StandFemale_22K/inference/mcep_cut_raw \
            --inference_db /lustre/atlas/zhanghui/StandFemale_22K/tfrecords/mcep_cut_raw/test \
            --noserving_export

            #--weights /gfs/atlastts/StandFemale_22K/log/mcep_cut_raw/train/mcep_7.ckpt \
            #--inference_save /gfs/atlastts/StandFemale_22K/inference/mcep_cut_raw \
            #--inference_db /gfs/atlastts/StandFemale_22K/tfrecords/mcep_cut_raw/test \

            #--log_device_placement \
            #--log_runtime_stats_per_step 2 \

    fi

fi

