#!/bin/bash

cp docker/gitconfig ~/.gitconfig
ctags -R /usr/lib/python3.5
