#!/bin/bash

set -x

if [[ $# == 0 ]];then
    # ./cp 000123
	echo "usage: $0 filename without suffix"
	exit 1
fi

if [[ ! -d ./demo/data ]];then
    mkdir ./demo/data
fi
#rm -r ./demo/data || true
#mkdir ./demo/data

if [[ $2 == 'cut' ]]; then
    if [[ $3 == 'post' ]];then
        # inference mcep
        cp ./demo/post/$1.*  ./demo/data/$1.enforce.mcep
    else
        # inference mcep
        cp /lustre/atlas/zhanghui/StandFemale_22K/inference/mcep_cut_normal/gpu/$1.*  ./demo/data/$1.enforce.mcep
    fi

    # nat mcep and f0
    cp /lustre/atlas/zhanghui/StandFemale_22K/MCEP/nature_par/scep_cut/$1.*  ./demo/data/$1.nat.mcep
    cp /lustre/atlas/zhanghui/StandFemale_22K/MCEP/nature_par/postf0_cut/$1.*  ./demo/data/$1.nat.f0

    # syn mcep and f0
    cp /lustre/atlas/zhanghui/StandFemale_22K/MCEP/gen_par/f0_cut/$1.*  ./demo/data/$1.syn.f0
    cp /lustre/atlas/zhanghui/StandFemale_22K/MCEP/gen_par/mcep_cut/$1.*  ./demo/data/$1.syn.mcep

    bash ./gen.sh ./demo/data/$1.syn.f0 ./demo/unvoice/$1.enforce.unvoice.mcep ./demo/data/$1.unvoice.wav

elif [[ $2 == 'no-cut' ]]; then
    if [[ $3 == 'post' ]];then
        # inference mcep
        cp ./demo/post/$1.*  ./demo/data/$1.enforce.mcep
    else
        # inference mcep
        cp /lustre/atlas/zhanghui/StandFemale_22K/inference/mcep_normal/gpu/$1.*  ./demo/data/$1.enforce.mcep
    fi

    # nat mcep and f0
    cp /lustre/atlas/zhanghui/StandFemale_22K/MCEP/nature_par/scep/$1.*  ./demo/data/$1.nat.mcep
    cp /lustre/atlas/zhanghui/StandFemale_22K/MCEP/nature_par/postf0/$1.*  ./demo/data/$1.nat.f0

    # syn mcep and f0
    cp /lustre/atlas/zhanghui/StandFemale_22K/MCEP/gen_par/f0/$1.*  ./demo/data/$1.syn.f0
    cp /lustre/atlas/zhanghui/StandFemale_22K/MCEP/gen_par/mcep/$1.*  ./demo/data/$1.syn.mcep

    bash ./gen.sh ./demo/data/$1.syn.f0 ./demo/unvoice/$1.enforce.unvoice.mcep ./demo/data/$1.unvoice.wav

fi

# syn f0 for wav
bash ./gen.sh ./demo/data/$1.syn.f0 ./demo/data/$1.enforce.mcep ./demo/data/$1.enforce.wav
bash ./gen.sh ./demo/data/$1.syn.f0 ./demo/data/$1.syn.mcep ./demo/data/$1.syn.wav
bash ./gen.sh ./demo/data/$1.syn.f0 ./demo/data/$1.nat.mcep ./demo/data/$1.nat.wav
bash ./gen.sh ./demo/data/$1.nat.f0 ./demo/data/$1.nat.mcep ./demo/data/$1.natf0.nat.wav

# mcep to txt for test
./x2x +f +a41 ./demo/data/$1.syn.mcep > ./demo/data/$1.syn.mcep.txt
./x2x +f +a41 ./demo/data/$1.nat.mcep > ./demo/data/$1.nat.mcep.txt
./x2x +f +a41 ./demo/data/$1.enforce.mcep > ./demo/data/$1.enforce.mcep.txt

# use GV
cp ./demo/data/$1.syn.mcep ./demo/data/$1.syn.gv.mcep
python mcep_gv.py --mceppath ./demo/data/$1.syn.gv.mcep
bash ./gen.sh ./demo/data/$1.syn.f0 ./demo/data/$1.syn.gv.mcep ./demo/data/$1.syn.gv.wav


for f in $(ls ./demo/data/*.wav)
do
  mv $f ${f%.*}.mp3
done
