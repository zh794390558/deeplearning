#!/bin/bash

set -x

if [[ $# == 0 ]];then
	echo "usage: $0 [cut|no-cut]"
	exit 1
fi

if [[ $1 == 'cut' ]]; then
   # replace mcep unvoice
    python replace_enforce_mcep_unvoice_by_syn_f0.py \
        --gen /lustre/atlas/zhanghui/StandFemale_22K/inference/mcep_cut_normal/gpu \
        --syn /lustre/atlas/zhanghui/StandFemale_22K/MCEP/gen_par/mcep_cut/ \
        --syn_f0 /lustre/atlas/zhanghui/StandFemale_22K/MCEP/gen_par/f0_cut/
elif [[ $1 == 'no-cut' ]]; then
   # replace mcep unvoice
   python replace_enforce_mcep_unvoice_by_syn_f0.py \
        --gen /lustre/atlas/zhanghui/StandFemale_22K/inference/mcep_normal/gpu \
        --syn /lustre/atlas/zhanghui/StandFemale_22K/MCEP/gen_par/mcep/ \
        --syn_f0 /lustre/atlas/zhanghui/StandFemale_22K/MCEP/gen_par/f0/
fi
