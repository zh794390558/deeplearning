#!/bin/bash

set -x

if [[ $# == 0 ]];then
    echo "usage: $0 "
    exit 1
fi

python mcep_post.py \
    --syn /lustre/atlas/zhanghui/StandFemale_22K/MCEP/gen_par/mcep/ \
    --gen /lustre/atlas/zhanghui/StandFemale_22K/inference/mcep_normal/gpu/ \
    --save ./demo/post
