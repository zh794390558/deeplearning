#!/usr/bin/env python

import numpy as np
import os
import argparse
import logging

FLAGS=None

def replace_unvoice(gen_in, syn_in, syn_f0_in):
    # mcep is bin file
    gen = np.fromfile(gen_in, dtype=np.float32)
    gen.shape = (-1, 41)
    syn = np.fromfile(syn_in, dtype=np.float32)
    syn.shape = (-1, 41)
    # f0 is txt, two columns, choice first colum
    f0 = np.fromfile(syn_f0_in, sep='\n')
    f0.shape = (-1, 2)
    f0 = f0[:, 0]

    # repalce syn mcep unvoiced feature to enforced mcep correspoding locations,
    # by f0 is zero
    # if f0 is zero, that indicate unvoice segment
    mask = (f0 == 0)
    gen[mask, :] = syn[mask, :]

    # 3 frame window smoothing
    for i in xrange(gen.shape[0] - 2):
        gen[i+1, :] = (gen[i, :] + gen[i+1, :] + gen[i+2, :]) / 3

    # save the replaced mcep to bin file
    filepath, ext = os.path.splitext(gen_in)
    savepath = os.path.basename(filepath) + '.enforce.unvoice' + ext
    savepath = os.path.join(FLAGS.save, savepath)
    gen.tofile(savepath)
    if not os.path.exists(FLAGS.save):
        os.makedirs(FLAGS.save)


def main():
    if not os.path.exists(FLAGS.save):
        os.makedirs(FLAGS.save)

    if os.path.isdir(FLAGS.gen):
       files = os.listdir(FLAGS.gen)
       print(files)
       for f in files:
           print('file {}'.format(f))
           # mcep
           genfilename = f
           synfilename = f
           # syn f0
           filename, ext = os.path.splitext(f)
           synf0filename = filename + '.f0'

           genpath = os.path.join(FLAGS.gen, genfilename)
           synpath = os.path.join(FLAGS.syn, synfilename)
           synf0path = os.path.join(FLAGS.syn_f0, synf0filename)

           assert os.path.exists(genpath), genpath
           assert os.path.exists(synpath), synpath
           assert os.path.exists(synf0path), (synf0path)

           replace_unvoice(genpath, synpath, synf0path)
    else:
        replace_unvoice(FLAGS.gen, FLAGS.syn, FLAGS.syn_f0)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='replace enforced mcep unvoice by syn mcep when mcep f0 is 0')
    parser.add_argument('--gen', type=str, required=True, help='enforced mcep')
    parser.add_argument('--syn', type=str, help='syn mcep')
    parser.add_argument('--syn_f0', type=str, help='mcep f0')
    parser.add_argument('--save', type=str, default='./demo/unvoice', help='mcep f0')
    FLAGS = parser.parse_args()
    main()
