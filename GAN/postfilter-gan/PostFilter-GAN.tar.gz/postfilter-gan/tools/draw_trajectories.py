import numpy as np
import matplotlib.pyplot as plt
import logging
import argparse
import os

FLAGS=None

syn='325046.syn.mcep'
nat='325046.nat.mcep'
gen='325046.enforce.mcep'
gv='325046.gv.mcep'

logging.basicConfig(level=logging.DEBUG)

def plt_fig(syn, gv, gen, nat):
    assert syn.size == gen.size
    assert syn.size == nat.size
    assert syn.size == gv.size
    x = np.arange(syn.size)
    assert x.size == syn.size
    
    plt.figure(figsize=(10,10))
    plt.plot(x, syn, 'r', label='syn')
    plt.plot(x, gv, 'g', label='gv')
    plt.plot(x, gen, 'k--', label='gen')
    plt.plot(x, nat, 'b', label='nat')
    plt.legend()
    plt.show()
    

def main():
    if not os.path.exists(FLAGS.syn) or not os.path.exists(FLAGS.nat) or \
        not os.path.exists(FLAGS.gv) or not os.path.exists(FLAGS.gen):
        raise ValueError('mcep file not exists')
        
    syn = np.fromfile(FLAGS.syn, np.float32).reshape(-1, 41)
    nat = np.fromfile(FLAGS.nat, np.float32).reshape(-1, 41)
    gv = np.fromfile(FLAGS.gv, np.float32).reshape(-1, 41)
    gen = np.fromfile(FLAGS.gen, np.float32).reshape(-1, 41)
   
    logging.debug('syn shape {}'.format(syn.shape))
    
    plt_fig(syn[:, FLAGS.dim], gv[:, FLAGS.dim], gen[:, FLAGS.dim], nat[:, FLAGS.dim])
    
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='draw trajectories')
    parser.add_argument('--nat', type=str, required=True, help='nat mcep')
    parser.add_argument('--syn', type=str, required=True, help='syn mcep')
    parser.add_argument('--gv', type=str, required=True, help='gv mcep')
    parser.add_argument('--gen', type=str, required=True, help='gen mcep')
    parser.add_argument('--dim', type=int, default=11, help='select this dimention to draw')
    FLAGS = parser.parse_args()
    main()
    
  