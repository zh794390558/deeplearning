#!/usr/bin/env python

import os
import logging
import argparse
import numpy as np
import tqdm

FLAGS=None

# min-max clipping for mcep

def post(gen_file, syn_file):
    syn = np.fromfile(syn_file, dtype=np.float32)
    syn.shape=(-1, 41)
    gen = np.fromfile(gen_file, dtype=np.float32)
    gen.shape=(-1, 41)

    res = np.clip(gen, syn.min(axis=0), syn.max(axis=0))
    assert res.dtype == np.float32, res.dtype

    filename, ext = os.path.splitext(os.path.basename(gen_file))
    save_path = os.path.join(FLAGS.save, filename + ext)
    res.tofile(save_path)

def main():
    if not os.path.exists(FLAGS.save):
        os.makedirs(FLAGS.save)

    if os.path.isdir(FLAGS.syn):
        files = os.listdir(FLAGS.gen)
        gen_files = [os.path.join(FLAGS.gen, f) for f in files]
        syn_files = [os.path.join(FLAGS.syn, f) for f in files]
        for gen, syn in tqdm.tqdm(zip(gen_files, syn_files)):
            post(gen, syn)
    else:
        post(FLAGS.gen, FLAGS.syn)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='mcep post process')
    parser.add_argument('--syn', type=str, help='syn mcep')
    parser.add_argument('--gen', type=str, help='gen mcep')
    parser.add_argument('--save', type=str, help='save path')
    FLAGS = parser.parse_args()
    main()
