#!/bin/bash

set -x

PID=$(ps aux | grep 'model/main.py' | grep -v grep | awk '{ print $2 }')

#kill -9 $PID

if [[ $# != 1 ]]; then
    echo "usage: ./run.sh [test|lsf|mcep]"
    exit 1
elif [[ $# == 1 ]]; then
    if [[ $1 == 'test' ]]; then
        python model/main.py  \
            --batch_size 6 \
            --epoch 2 \
            --mode wgan-gp \
            --bitdepth 32 \
            --network model.py \
            --networkDirectory . \
            --optimization adam \
            --lr_base_rate 0.0001 \
            --lr_polcy fixed \
            --train_db data/train \
            --validation_db data/val \
            --save log/train \
            --save_vars trainable \
            --summaries_dir log/summaries \
            --seed 10 \
            --shuffle True\
            --snapshotPrefix test \
            --snapshotInterval 3 \
            --validation_interval 1 \
            --log_runtime_stats_per_step 1 \
            --noserving_export
            #--noshuffle \
            #--log_device_placement \
            #--log_runtime_stats_per_step 2 \
    elif [[ $1 == 'lsf' ]]; then
        python model/main.py  \
            --batch_size 64 \
            --epoch 200000 \
            --bitdepth 32 \
            --mode wgan-gp \
            --network model.py \
            --networkDirectory . \
            --optimization adam \
            --lr_base_rate 0.000001 \
            --lr_polcy fixed \
            --weights /gfs/atlastts/StandFemale_22K/log/train/gan_18976.ckpt \
            --train_db /gfs/atlastts/StandFemale_22K/tfrecords/train \
            --validation_db /gfs/atlastts/StandFemale_22K/tfrecords/val \
            --save /gfs/atlastts/StandFemale_22K/log/train \
            --save_vars trainable \
            --summaries_dir /gfs/atlastts/StandFemale_22K/log/summaries \
            --seed 10 \
            --shuffle True\
            --snapshotPrefix lsf \
            --snapshotInterval 10 \
            --validation_interval 10 \
            --noserving_export
            #--noshuffle \
            #--log_device_placement \
            #--log_runtime_stats_per_step 2 \

    elif [[ $1 == 'mcep' ]]; then
        python model/main.py  \
            --batch_size 64 \
            --epoch 200000 \
            --mode wgan-gp \
            --bitdepth 32 \
            --network model.py \
            --networkDirectory . \
            --optimization adam \
            --lr_base_rate 0.000001 \
            --lr_polcy fixed \
            --seed 10 \
            --shuffle True\
            --save_vars trainable \
            --save /gfs/atlastts/StandFemale_22K/log/mcep/train \
            --summaries_dir /gfs/atlastts/StandFemale_22K/log/mcep/summaries \
            --train_db /gfs/atlastts/StandFemale_22K/tfrecords/mcep/train \
            --validation_db /gfs/atlastts/StandFemale_22K/tfrecords/mcep/val \
            --snapshotPrefix mcep \
            --snapshotInterval 1 \
            --validation_interval 1 \
            --noserving_export
            #--weights /gfs/atlastts/StandFemale_22K/log/train/gan_18976.ckpt \
            #--noshuffle \
            #--log_device_placement \
            #--log_runtime_stats_per_step 2 \
    elif [[ $1 == 'mcep_normal' ]]; then
        python model/main.py  \
            --batch_size 64 \
            --epoch 200000 \
            --mode wgan-gp \
            --bitdepth 32 \
            --network model.py \
            --networkDirectory . \
            --optimization adam \
            --lr_base_rate 0.000001 \
            --lr_polcy fixed \
            --seed 10 \
            --shuffle True\
            --save_vars trainable \
            --save /gfs/atlastts/StandFemale_22K/log/mcep_normal/train \
            --summaries_dir /gfs/atlastts/StandFemale_22K/log/mcep_normal/summaries \
            --train_db /gfs/atlastts/StandFemale_22K/tfrecords/mcep_normal/train \
            --validation_db /gfs/atlastts/StandFemale_22K/tfrecords/mcep_normal/val \
            --snapshotPrefix mcep_normal \
            --snapshotInterval 1 \
            --validation_interval 1 \
            --noserving_export
            #--weights /gfs/atlastts/StandFemale_22K/log/train/gan_18976.ckpt \
            #--noshuffle \
            #--log_device_placement \
            #--log_runtime_stats_per_step 2 \
    elif [[ $1 == 'mcep_cut' ]]; then
        python model/main.py  \
            --batch_size 128 \
            --epoch 2000 \
            --mode lsgan \
            --bitdepth 32 \
            --network model.py \
            --networkDirectory . \
            --optimization adam \
            --lr_base_rate 1e-4 \
            --lr_polcy exp \
            --lr_gamma 0.9 \
            --shuffle True\
            --save_vars trainable \
            --summaries_dir /lustre/atlas/zhanghui/StandFemale_22K/log/mcep_cut/summaries \
            --train_db /gfs/atlastts/StandFemale_22K/tfrecords/mcep_cut_normal/train \
            --validation_db /gfs/atlastts/StandFemale_22K/tfrecords/mcep_cut_normal/val \
            --save /lustre/atlas/zhanghui/StandFemale_22K/log/mcep_cut/train/2gpu \
            --snapshotPrefix lsgan_l1_1e-6 \
            --snapshotInterval 1 \
            --validation_interval 1 \
            --noserving_export
            #--weights /lustre/atlas/zhanghui/StandFemale_22K/log/mcep_cut/train/mcep_cut_13.ckpt \
            #--seed 10 \
            #--noshuffle \
            #--log_device_placement \
            #--log_runtime_stats_per_step 2 \
    elif [[ $1 == 'mcep_cut_raw' ]]; then
        python model/main.py  \
            --batch_size 64 \
            --epoch 200000 \
            --mode wgan-gp \
            --bitdepth 32 \
            --network model.py \
            --networkDirectory . \
            --optimization adam \
            --lr_base_rate 0.000001 \
            --lr_polcy fixed \
            --seed 10 \
            --shuffle True\
            --save_vars trainable \
            --save /lustre/atlas/zhanghui/StandFemale_22K/log/mcep_cut_raw/train/100f \
            --summaries_dir /lustre/atlas/zhanghui/StandFemale_22K/log/mcep_cut_raw/summaries \
            --train_db /lustre/atlas/zhanghui/StandFemale_22K/tfrecords/mcep_cut_raw/train \
            --validation_db /lustre/atlas/zhanghui/StandFemale_22K/tfrecords/mcep_cut_raw/val \
            --snapshotPrefix mcep_cut_raw \
            --snapshotInterval 1 \
            --validation_interval 1 \
            --log_runtime_stats_per_step 10 \
            --weights_latest \
            --noserving_export
            #--weights /gfs/atlastts/StandFemale_22K/log/mcep_cut_raw/train/mcep_50.ckpt \
            #--noshuffle \
            #--log_device_placement \
            #--log_runtime_stats_per_step 2 \
    fi

fi

