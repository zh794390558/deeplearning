import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import SymLogNorm, Normalize
import argparse
import os
import shutil
import logging

FLAGS = None

def plt_fig(nat, syn, enforce, save):
    x, y = nat.shape
    X,Y = np.mgrid[0:x, 0:y]
    #print(X,Y)

    #fig, axes = plt.subplots(4,1, figsize=(20, 20))
    plt.figure(figsize=(20,20))

    plt.subplot(3,1,2)
    #cax=ax.matshow(raw, cmap=plt.cm.Spectral_r, interpolation='None', vmin=0, vmax=1)
    #plt.pcolor(Y, X, raw,  cmap='PuBu_r', norm=SymLogNorm(vmin=-raw.max(), vmax=raw.max(), linthresh=0.4))
    #plt.pcolormesh(Y, X, raw,  cmap='rainbow', norm=Normalize(vmin=-1, vmax=1), alpha=0.8, linewidths=0.1)
    
    plt.pcolormesh(X, Y, enforce, cmap=FLAGS.cmap, alpha=1)
    plt.xlabel('$frames$')
    plt.ylabel('$MCC$')
    plt.title('ENFORCE')
    ax1 = plt.gca()


    plt.subplot(3,1,1, sharex=ax1, sharey=ax1)
    plt.pcolormesh(X, Y, syn, cmap=FLAGS.cmap, alpha=1)
    plt.xlabel('$frames$')
    plt.ylabel('$MCC$')
    plt.title('SYN')


    plt.subplot(3,1,3, sharex=ax1, sharey=ax1)
    plt.pcolormesh(X, Y, nat, cmap=FLAGS.cmap,  alpha=1)
    plt.xlabel('$frames$')
    plt.ylabel('$MCC$')
    plt.title('NAT')

    plt.colorbar(ax=plt.gcf().get_axes(), shrink=0.75)

    #plt.ion()
    #plt.show()

    plt.savefig(save, format='png')
    plt.cla()
    plt.clf()
    plt.close()


def get_data(filename):
    raw = np.fromfile(filename, dtype=np.float32)
    print('The size of data is {} bytes'.format(raw.size * 4))

    raw = raw.reshape((-1, 41))
    print(raw.shape)

    return raw

def main(_):
    # dir
    if os.path.isdir(FLAGS.nat) or os.path.isdir(FLAGS.syn) or os.path.isdir(FLAGS.enforce):
        # preapre save
        if os.path.exists(FLAGS.save):
            shutil.rmtree(FLAGS.save, ignore_errors=True)
        os.makedirs(FLAGS.save)

        nat_dir, syn_dir, enforce_dir = FLAGS.nat, FLAGS.syn, FLAGS.enforce

        nat_files = os.listdir(nat_dir)
        syn_files = os.listdir(syn_dir)
        enforce_files = os.listdir(enforce_dir)
        logging.info(enforce_files)

        nat_suffix = os.path.splitext(nat_files[0])[1]
        syn_suffix = os.path.splitext(syn_files[0])[1]
        enforce_suffix = os.path.splitext(enforce_files[0])[1]
        logging.info('suffix: nat {}, syn {}, enforce {}'.format(nat_suffix, syn_suffix, enforce_suffix))

        enforce_names, nat_names, syn_names = [], [], []
        for enforce_file, nat_file, syn_file in zip(enforce_files, nat_files, syn_files):
            enforce_names.append(os.path.splitext(enforce_file)[0])
            nat_names.append(os.path.splitext(nat_file)[0])
            syn_names.append(os.path.splitext(syn_file)[0])

        for enforce_name in enforce_names:
            try:
                if enforce_name not in nat_names or \
                   enforce_name not in syn_names:
                       raise ValueError('{} not has corresponding files in nat or syn'.format(enforce_name + enforce_suffix))
            except ValueError as e:
                logging.error(e)
                continue

            nat_file, syn_file, enforce_file = enforce_name + nat_suffix, \
                                               enforce_name + syn_suffix, \
                                               enforce_name + enforce_suffix

            nat, syn, enforce = get_data(nat_file), get_data(syn_file), get_data(enforce_file)

            save = os.path.join(FLAGS.save, enforce_name+'.png')

            plt_fig(nat, syn, enforce, save)
    else: # file
        nat, syn, enforce = get_data(FLAGS.nat), get_data(FLAGS.syn), get_data(FLAGS.enforce)
        nat = nat[:, FLAGS.cut:]
        syn = syn[:, FLAGS.cut:]
        enforce = enforce[:, FLAGS.cut:]
        plt_fig(nat, syn, enforce, FLAGS.save)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Plot Mcep figure')
    parser.add_argument('--nat', type=str, default=None, help='Nature mcep dir or file name')
    parser.add_argument('--syn', type=str, default=None, help='Synthesised mcep dir or file  name')
    parser.add_argument('--enforce', type=str, default=None, help='Enforced mcep dir or file name')
    parser.add_argument('--save', type=str, default=None, help='File path to save the figure')
    parser.add_argument('--cmap', type=str, default='hsv', help='color map')
    parser.add_argument('--cut', type=int, default=5, help='Cut low $num$ dimension of 41 features')

    FLAGS = parser.parse_args()
    main(FLAGS)
