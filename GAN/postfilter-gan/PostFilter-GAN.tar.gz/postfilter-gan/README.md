# [GENERATIVE ADVERSARIAL NETWORK-BASED POSTFILTER FOR STATISTICAL PARAMETRIC SPEECH SYNTHESIS](http://www.kecl.ntt.co.jp/people/kameoka.hirokazu/publications/Kaneko2017ICASSP03_published.pdf)

* [Generative Adversarial Network-based Postfilter for STFT Spectrograms](http://www.kecl.ntt.co.jp/people/kameoka.hirokazu/publications/Kaneko2017Interspeech08b_published.pdf)

* [Direct modeling of frequency spectra and waveform generation based on phase recovery for DNN-based speech synthesis](http://www.kecl.ntt.co.jp/people/kameoka.hirokazu/publications/Takaki2017Interspeech08_published.pdf)

# data 

1. 大约 13~14h 的含静音的数据集。

1. SYN(合成语音) 和 NAT(自然语音) 特征是对齐的。

# Notes

1. 尝试 FCN 上输入变成语音，但是这种实现需要 batch_size 为 1， 且不能有 Padding 的数据。

1. 在切除静音的数据集上测试，会出现开头 80 帧左右的数值很小，导致合成的语音语谱图上只有 pitch 的能量。

1. 在含静音的数据集上测试，使用 slipping window + 50% overlap，固定输入 41(MCC)x200(frames) ， 可以收敛。

1. 使用 NAT 的 F0 且最终结果好于 SYN 的语音，但是差于 NATUARE 的语音。但是，使用 NAT F0 会出现部分基频模糊现象。更改为 SYN F0 后此问题消失。  

1. Inference 时使用分帧 inference 的方式，最后拼接成整个语音。在每帧的连接处的语谱图上有一条竖线。更改为整段语音 inference 后，此问题解决。

1. z-score norm of data, lsgan, lr=1e-4, batch_size=128, no-batchnorm, G L1 lambda is 1e-6 or 1e-5.

# Reference

1. [DIGITS-GAN](https://github.com/NVIDIA/DIGITS)

* [GAN-mnist](https://github.com/NVIDIA/DIGITS/blob/master/examples/gan/network-mnist.py)

* [Model Exmaples](https://github.com/NVIDIA/DIGITS/tree/master/examples)

* [Model Template](https://github.com/NVIDIA/DIGITS/tree/master/digits/tools/tensorflow)

1. [DCGAN](https://github.com/carpedm20/DCGAN-tensorflow/)

1. [SEGAN: Speech Enhancement Generative Adversarial Network](https://github.com/santi-pdp/segan)

* 4.2 SEGAN's setup is a good guide to this work.

1. NTT

# TODO


